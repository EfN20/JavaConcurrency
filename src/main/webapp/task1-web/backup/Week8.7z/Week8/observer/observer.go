package main

import "fmt"

type subject interface{
	subscribe(User observer)
	unsubscribe(User observer)
	notifyAll()
}

type application struct{
	subscribedUsers []observer
	name string
	newUpdate bool
}

func (a *application) subscribe(u observer){
	a.subscribedUsers = append(a.subscribedUsers, u)
}

func (a *application) unsubscribe(u observer){
	a.subscribedUsers = deleteFromSubscribers(a.subscribedUsers, u)
}

func (a *application) notifyAll(){
	for _, user := range a.subscribedUsers {
		user.update(a.name)
	}
}

func deleteFromSubscribers(subscribedUsers []observer, unsubUser observer) []observer{
	lengUsers := len(subscribedUsers)
	for i, user := range subscribedUsers{
		if unsubUser.getUsername() == user.getUsername(){
			subscribedUsers[lengUsers - 1], subscribedUsers[i] = subscribedUsers[i], subscribedUsers[lengUsers - 1]
			return subscribedUsers[:lengUsers - 1]
		}
	}
	return subscribedUsers
}

func newApplication(name string) *application{
	return &application{name: name}
}

func (a *application) updateRelease(){
	fmt.Printf("New update is available to %s!\n", a.name)
	a.newUpdate = true
	a.notifyAll()
}

type observer interface {
	update(string)
	getUsername() string
}

type user struct{
	username string
}

func (u *user) update(appName string){
	fmt.Printf("Sending notification to %s about update in %s...\n", u.getUsername(), appName)
}

func (u *user) getUsername() string{
	return u.username
}

func main(){
	app := newApplication("VSCO")
	app2 := newApplication("Dazz Camera")

	azatkali := &user{"EfN"}
	azatkali2 := &user{"Chinga"}

	//app.subscribe(azatkali)
	app.subscribe(azatkali)
	app2.subscribe(azatkali)
	app2.subscribe(azatkali2)

	app.updateRelease()
	fmt.Println()
	app2.updateRelease()

	fmt.Println()
	fmt.Println()
	app.unsubscribe(azatkali)
	app2.unsubscribe(azatkali)
	fmt.Println("AZAZAZA")
	fmt.Println()
	app.updateRelease()
	fmt.Println()
	app2.updateRelease()
}

//	OUTPUT
//	New update is available to VSCO!
//	Sending notification to EfN about update in VSCO...
//
//	New update is available to Dazz Camera!
//	Sending notification to EfN about update in Dazz Camera...




