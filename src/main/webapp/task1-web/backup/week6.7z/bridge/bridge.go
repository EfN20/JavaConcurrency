package bridge

import "fmt"

type Freelancer interface{
	WriteBackEnd()
	WriteFrontEnd()
}

type OldJuniorStack struct{

}

func (ojs *OldJuniorStack) WriteBackEnd(){
	fmt.Println("I can write and support backend with PHP")
}

func (ojs *OldJuniorStack) WriteFrontEnd(){
	fmt.Println("I can write and support frontend with Jquery")
}

type NewJuniorStack struct{

}

func (njs *NewJuniorStack) WriteBackEnd(){
	fmt.Println("I can write and support backend with Node.js")
}

func (njs *NewJuniorStack) WriteFrontEnd(){
	fmt.Println("I can write and support frontend with Vue.js")
}

type BackEnd struct{
	freelancer Freelancer
}

func (b *BackEnd) Do(){
	b.freelancer.WriteBackEnd()
}

func NewBackEnd(freelancer Freelancer) *BackEnd{
	return &BackEnd{freelancer: freelancer}
}

type FrontEnd struct{
	freelancer Freelancer
}

func (f *FrontEnd) Do(){
	f.freelancer.WriteFrontEnd()
}

func NewFrontEnd(freelancer Freelancer) *FrontEnd{
	return &FrontEnd{freelancer: freelancer}
}

func main(){
	oldStack := OldJuniorStack{}
	oldSiteBackEnd := NewBackEnd(&oldStack)
	oldSiteBackEnd.Do()

	fmt.Println()

	newStack := NewJuniorStack{}
	oldSiteFrontEnd := NewFrontEnd(&newStack)
	oldSiteFrontEnd.Do()


	fmt.Println("After changing backend stack")
	oldSiteBackEnd = NewBackEnd(&newStack)
	oldSiteBackEnd.Do()

}


