package main

import "fmt"

type Rifle interface{
	Fire() string
}

type VarmintRifle struct{
	Ammo string
}

func (v *VarmintRifle) Fire() string{
	return fmt.Sprintf("Shot from varmint rifle with %s", v.Ammo)
}

type HuntingRifle struct{
	Ammo string
}

func (h *HuntingRifle) Fire() string{
	return fmt.Sprintf("Shot from hunting rifle with %s", h.Ammo)
}

type ScopedRifle struct{
	Rifle Rifle
}

func (sr *ScopedRifle) Fire() string{
	return fmt.Sprintf("%s with scope", sr.Rifle.Fire())
}

type SilencedRifle struct{
	Rifle Rifle
}

func (s *SilencedRifle) Fire() string{
	return fmt.Sprintf("%s with silencer", s.Rifle.Fire())
}

func main(){
	vr := VarmintRifle{Ammo: "5.56mm round"}
	hr := HuntingRifle{Ammo: ".308 round"}

	fmt.Println(vr.Fire())
	fmt.Println()

	vrSilenced := SilencedRifle{Rifle: &vr}
	fmt.Println(vrSilenced.Fire())
	fmt.Println()

	vrSilAndScoped := ScopedRifle{Rifle: &vrSilenced}
	fmt.Println(vrSilAndScoped.Fire())
	fmt.Println()

	fmt.Println(hr.Fire())
	hrScoped := ScopedRifle{Rifle: &hr}
	fmt.Println(hrScoped.Fire())


}
