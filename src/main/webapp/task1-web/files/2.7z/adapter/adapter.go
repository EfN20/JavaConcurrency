package adapter

import "fmt"

//couldn't think for better examples

type companion struct{

}

func (c *companion) use308CaliberAmmo(w weapon){
	fmt.Println("Companion inserting .308 caliber ammo into his weapon")
	w.insertCommonAmmoIntoMagazine()
}

type weapon interface{
	insertCommonAmmoIntoMagazine()
}

type standardWeapon struct{

}

func (sw *standardWeapon) insertCommonAmmoIntoMagazine(){
	fmt.Println("Inserting into magazine .308 caliber ammo")
}

type highLevelWeapon struct{

}

func (hlw *highLevelWeapon) insertRareAmmoIntoMagazine(){
	fmt.Println("Inserting into magazine .50 caliber ammo")
}

type caliber50Adapter struct{
	hlw *highLevelWeapon
}

func (c50a *caliber50Adapter) insertCommonAmmoIntoMagazine(){
	fmt.Println("Adapted weapon to .50 caliber ammo")
	c50a.hlw.insertRareAmmoIntoMagazine()
}

func main(){
	starterCompanion := &companion{}
	companionWeapon := &standardWeapon{}
	starterCompanion.use308CaliberAmmo(companionWeapon)
	fmt.Println()

	betterWeapon := &highLevelWeapon{}
	betterWeaponAmmoAdapter := &caliber50Adapter{hlw: betterWeapon}
	starterCompanion.use308CaliberAmmo(betterWeaponAmmoAdapter)

}

