package main

import (
	"fmt"
	"log"
)

type character struct{
	name string
}

func newCharacter(name string) *character{
	return &character{name: name}
}

func (c *character) checkCharacter(name string) error{
	if c.name != name{
		return fmt.Errorf("Character's name is not matching!")
	}
	fmt.Println("Character verified")
	return nil
}

type characterLevel struct{
	level int
}

func newCharacterLevel(level int) *characterLevel{
	return &characterLevel{level: level}
}

func (cl *characterLevel) checkLevel(level int) error{
	if cl.level < level{
		return fmt.Errorf("Character's level is less than items!")
	}
	fmt.Println("Level verified")
	return nil
}

type characterSkill struct{
	skill int
}

func newCharacterSkill(skill int) *characterSkill{
	return &characterSkill{skill: skill}
}

func (cs *characterSkill) checkSkill(skill int) error{
	if cs.skill < skill{
		return fmt.Errorf("Character's skill is less than items!")
	}
	fmt.Println("Skill verified")
	return nil
}

type Fraction string

const(
	NCR    Fraction = "NCR"
	Legion          = "Caesar's Legion"
	House           = "Mr. House"
	YesMan          = "Independent Vegas"
)

type characterFraction struct{
	fraction Fraction
}

func newCharacterFraction(f Fraction) *characterFraction{
	return &characterFraction{fraction: f}
}

func (cf *characterFraction) checkFraction(f Fraction) error{
	if cf.fraction != f{
		return fmt.Errorf("Character's fraction is not matching!")
	}
	fmt.Println("Fraction verified")
	return nil
}

type pipboy struct{
	bottlecaps int
}

func newPipboy() *pipboy{
	return &pipboy{bottlecaps: 0}
}

func (pb *pipboy) addBottleCaps(amount int){
	pb.bottlecaps += amount
	fmt.Println("Pipboy balance added successfully")
}

func (pb *pipboy) removeBottleCaps(amount int) error{
	if pb.bottlecaps < amount{
		return fmt.Errorf("Not enought bottlecaps!")
	}
	fmt.Println("Enought bottlecaps")
	pb.bottlecaps = pb.bottlecaps - amount
	return nil
}

type history struct {
}

func (h *history) makeEntry(characterName, txnType string, amount int) {
	fmt.Printf("Make hsitory entry for characterName %s with txnType %s for amount %d", characterName, txnType, amount)
	return
}

type notification struct {
}

func (n *notification) sendPipboyAddNotification() {
	fmt.Println("Sending pipboy add notification")
}

func (n *notification) sendPipboyRemoveNotification() {
	fmt.Println("Sending pipboy remove notification")
}

type pipboyFacade struct{
	character *character
	characterLevel *characterLevel
	characterSkill *characterSkill
	characterFraction *characterFraction
	pipboy *pipboy
	history *history
	notification *notification
}

func newPipboyFacade(characterName string, level int, skill int, fraction Fraction) *pipboyFacade{
	fmt.Println("Creating new character")
	pipboyFacade := &pipboyFacade{
		character: newCharacter(characterName),
		characterLevel: newCharacterLevel(level),
		characterSkill: newCharacterSkill(skill),
		characterFraction: newCharacterFraction(fraction),
		pipboy: newPipboy(),
		history: &history{},
		notification: &notification{},
	}
	fmt.Println("Character created")
	return pipboyFacade
}

func (pb *pipboyFacade) addBottleCapsToPipboy(characterName string, amount int) error{
	fmt.Println("Adding bottlecaps to pipboy")
	err := pb.character.checkCharacter(characterName)
	if err != nil{
		return err
	}

	pb.pipboy.addBottleCaps(amount)
	pb.notification.sendPipboyAddNotification()
	pb.history.makeEntry(characterName, "add", amount)
	return nil
}

func (pb *pipboyFacade) removeBottleCapsFromPipboy(characterName string, level int, skill int, fraction Fraction, amount int) error{
	fmt.Println("removing bottlecaps from pipboy")
	err := pb.character.checkCharacter(characterName)
	if err != nil{
		return err
	}

	err = pb.characterLevel.checkLevel(level)
	if err != nil{
		return err
	}

	err = pb.characterSkill.checkSkill(skill)
	if err != nil{
		return err
	}

	err = pb.characterFraction.checkFraction(fraction)
	if err != nil{
		return err
	}

	err = pb.pipboy.removeBottleCaps(amount)
	if err != nil{
		return err
	}

	pb.notification.sendPipboyRemoveNotification()
	pb.history.makeEntry(characterName, "remove", amount)
	return nil
}

func main(){
	pipboyFacade := newPipboyFacade("EfN", 20, 55, NCR)
	fmt.Println()
	err := pipboyFacade.addBottleCapsToPipboy("EfN", 1500)
	if err != nil {
		log.Fatalf("Error: %s\n", err.Error())
	}
	fmt.Println()
	err = pipboyFacade.removeBottleCapsFromPipboy("EfN", 19, 54, YesMan, 1000)
	if err != nil {
		log.Fatalf("Error: %s\n", err.Error())
	}

}