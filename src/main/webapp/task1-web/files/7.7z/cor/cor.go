package cor

import "fmt"

//preparation for end-game dlc
type preparation interface{
	getItems(*character)
	setNext(preparation)
}

type ncrSupplier struct{
	next preparation
}

func (n *ncrSupplier) getItems(c *character){
	if c.getGunAmmo{
		fmt.Printf("%s already purchased tons of gun ammo\n", c.name)
		n.next.getItems(c)
		return
	}
	fmt.Printf("%s purchasing tons of gun ammo\n", c.name)
	c.getGunAmmo = true
	n.next.getItems(c)
}

func (n *ncrSupplier) setNext(next preparation){
	n.next = next
}

type bosSupplier struct{
	next preparation
}

func (b *bosSupplier) getItems(c *character){
	if c.getEnergyAmmo{
		fmt.Printf("%s already purchased tons of eneregy weapon ammo\n", c.name)
		b.next.getItems(c)
		return
	}
	fmt.Printf("%s purchasing tons of eneregy weapon ammo\n", c.name)
	c.getEnergyAmmo = true
	b.next.getItems(c)
}

func (b *bosSupplier) setNext(next preparation){
	b.next = next
}

type neutralSupplier struct{
	next preparation
}

func (nt *neutralSupplier) getItems(c *character){
	if c.getAids{
		fmt.Printf("%s already purchased tons of aids\n", c.name)
		nt.next.getItems(c)
		return
	}
	fmt.Printf("%s purchasing tons of aids\n", c.name)
	c.getAids = true
	nt.next.getItems(c)
}

func (nt *neutralSupplier) setNext(next preparation){
	nt.next = next
}

type endGameDLC struct{
	next preparation
}

func (dlc *endGameDLC) getItems(c *character){
	if c.getFullPrepared{
		fmt.Printf("%s was ready for End-Game DLC time ago\n", c.name)
		return
	}
	fmt.Printf("%s is now ready for End-Game DLC!\n", c.name)
	fmt.Println("LET'S GOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
	c.getFullPrepared = true
}

func (dlc *endGameDLC) setNext(next preparation){
	dlc.next = next
}

type character struct {
	name string
	getGunAmmo bool
	getEnergyAmmo bool
	getAids bool
	getFullPrepared bool
}

func main(){
	dlc := &endGameDLC{}

	aid := &neutralSupplier{}
	aid.setNext(dlc)

	energyAmmo := &bosSupplier{}
	energyAmmo.setNext(aid)

	gunAmmo := &ncrSupplier{}
	gunAmmo.setNext(energyAmmo)

	azatkali := &character{name: "EfN"}
	gunAmmo.getItems(azatkali)
}

//	OUTPUT
//	EfN purchasing tons of gun ammo
//	EfN purchasing tons of eneregy weapon ammo
//	EfN purchasing tons of aids
//	EfN was ready for End-Game DLC time ago