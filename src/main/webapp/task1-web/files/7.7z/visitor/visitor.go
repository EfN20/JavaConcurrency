package visitor

import "fmt"

type supplier interface{
	getName() string
	supply(purpose)
}

type ncrSupplier struct{

}

func (n *ncrSupplier) getName() string{
	return "NCR Main Supplier"
}

func (n *ncrSupplier) supply(p purpose){
	p.getFromNCR(n)
}

type bosSupplier struct{

}

func (b *bosSupplier) getName() string{
	return "Brotherhood Of Steel Main Supplier"
}

func (b *bosSupplier) supply(p purpose){
	p.getFromBoS(b)
}

type neutralSupplier struct{

}

func (nt *neutralSupplier) getName() string{
	return "Neutral Fraction Main Supplier"
}

func (nt *neutralSupplier) supply(p purpose){
	p.getFromNeutral(nt)
}

type purpose interface{
	getFromNCR(*ncrSupplier)
	getFromBoS(*bosSupplier)
	getFromNeutral(*neutralSupplier)
}

type forAmmo struct{

}

func (f *forAmmo) getFromNCR(n *ncrSupplier){
	fmt.Println("Getting tons of guns ammo")
}

func (fAmmo *forAmmo) getFromBoS(b *bosSupplier){
	fmt.Println("Getting tons of energy weapon ammo")
}

func (f *forAmmo) getFromNeutral(nu *neutralSupplier){
	fmt.Println("Getting little of guns ammo and little of energy weapon ammo")
}

type forAid struct{

}

func (fAid *forAid) getFromNCR(n *ncrSupplier){
	fmt.Println("Getting few of stimpaks")
}

func (fAid *forAid) getFromBoS(b *bosSupplier){
	fmt.Println("Getting enough of super stimpaks")
}

func (fAid *forAid) getFromNeutral(nu *neutralSupplier){
	fmt.Println("Getting a lot of buffouts, med-xs' and radaways")
}

func main(){
	ncr := &ncrSupplier{}
	bos := &bosSupplier{}
	nu := &neutralSupplier{}

	//==========================================================
	ammo := &forAmmo{}

	fmt.Println(ncr.getName())
	ncr.supply(ammo)
	fmt.Println()

	fmt.Println(bos.getName())
	bos.supply(ammo)
	fmt.Println()

	fmt.Println(nu.getName())
	nu.supply(ammo)
	fmt.Println()

	//==========================================================
	aid := &forAid{}

	fmt.Println(ncr.getName())
	ncr.supply(aid)
	fmt.Println()

	fmt.Println(bos.getName())
	bos.supply(aid)
	fmt.Println()

	fmt.Println(nu.getName())
	nu.supply(aid)
	fmt.Println()
}

//	OUTPUT
//	NCR Main Supplier
//	Getting tons of guns ammo
//
//	Brotherhood Of Steel Main Supplier
//	Getting tons of energy weapon ammo
//
//	Neutral Fraction Main Supplier
//	Getting little of guns ammo and little of energy weapon ammo
//
//	NCR Main Supplier
//	Getting few of stimpaks
//
//	Brotherhood Of Steel Main Supplier
//	Getting enough of super stimpaks
//
//	Neutral Fraction Main Supplier
//	Getting a lot of buffouts, med-xs' and radaways



